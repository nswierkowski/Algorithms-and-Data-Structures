package lab4;

public interface change {

	public void change();
}
