package lab9;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program p = new Program();
		p.ReadFromFile("text.txt");
		p.Execute();
	}

}